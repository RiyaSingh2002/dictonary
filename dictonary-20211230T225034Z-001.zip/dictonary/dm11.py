my_dict = {
    'a':50, 
    'b':58, 
    'c':56,
    'd':40, 
    'e':100, 
    'f':20
    }
max=0
second_max=0
for i in my_dict:
    if max<my_dict[i]:
        max=my_dict[i]
        print(max)
    elif my_dict[i]<max and my_dict[i]>second_max:
        print(second_max)
    else:
        print('third_max') 