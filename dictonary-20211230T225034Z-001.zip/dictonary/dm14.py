this_dict={'subhashree':45,"pooja":45,"riya":66,"saijyoti":90,"naaz":78}
for x in this_dict:
    for y in this_dict:
        this_dict[x]>this_dict[y]
        this_dict[x],this_dict[y]=this_dict[y],this_dict[x]
print(this_dict)    

