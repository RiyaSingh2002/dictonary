
my_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# solution 1
dict_sum = sum(my_dict.values())
print(dict_sum)

# solution 2
dict_sum = 0
for k, v in my_dict.items():
    dict_sum += v
print(dict_sum)