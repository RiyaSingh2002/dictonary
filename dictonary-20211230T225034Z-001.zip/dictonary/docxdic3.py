n=int(input("enter any number"))
my_dict = {x: x**2 for x in range(1, n+1)}
print(my_dict)