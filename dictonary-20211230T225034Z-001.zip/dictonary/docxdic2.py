word = "w3resorce"
i=0
dic={}
while i<len(word):
    j=0
    count=0
    while j<len(word):
        if word[i]==word[j]:
            count+=1
        dic[word[i]]=count
        j+=1
    i+=1
print(dic)


