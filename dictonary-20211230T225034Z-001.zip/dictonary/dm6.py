dic={
    "ball":"red",
    "bat":4,
    "wickets":8,
    "ball":"green"
    "bat":3
    }
y=[]
x=dic()
for key,val in dic.item():
    if val not in dic:
        y.append(val)
        x[dic]=val
print(str(x))        

