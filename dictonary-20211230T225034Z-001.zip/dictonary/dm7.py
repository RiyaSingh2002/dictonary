dict=[
     {"first":"1"}, 
     {"second": "2"}, 
     {"third": "1"}, 
     {"four": "5"}, 
     {"five":"5"}, 
     {"six":"9"},
     {"seven":"7"}
]
y=[]
x=()
for key,val in dict.items():
    for value in val:
        if y.count(val)==1:
            x.append(key)
            break
print(str(x))        

