c=dict()
for i in range(1,16):
    c[i]=i*i
print(c)

