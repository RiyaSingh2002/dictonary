dict_one = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
dict_two = {'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 0}
for key in dict_two:                
    dict_one[key] = dict_two[key]  

print(dict_one)