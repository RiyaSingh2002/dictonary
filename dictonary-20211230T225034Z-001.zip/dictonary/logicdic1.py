d1=[{1:20,2:30}]
d2=[{6:50,2:40}]
d={}
for i in d1:
    for j in d2:
        for v,a in i.items():
            for s, k in j.items():
                if v==s:
                    c=a+k
                    d[v]=c
                    break
                else:
                    d[v]=a
                    d[s]=k
print(d)