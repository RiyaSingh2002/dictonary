d= {'1':['a','b'], '2':['c','d']}
# # solution1
# print(d["1"][0], d["2"][0])
# print(d["1"][0], d["2"][1])
# print(d["1"][1], d["2"][0])
# print(d["1"][1], d["2"][1])


# solution2
my_list = list(d.values())
print(my_list)
for i in my_list[0]:
    for j in range(1, len(my_list)):
        for x in my_list[j]:
            my_string = i + x
            print(my_string)