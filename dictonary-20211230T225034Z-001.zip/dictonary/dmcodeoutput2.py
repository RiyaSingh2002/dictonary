a = {'a':1,'b':2,'c':3}


print (a['a','b'])