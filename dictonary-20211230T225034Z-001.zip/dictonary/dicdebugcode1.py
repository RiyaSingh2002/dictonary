details={

    "name":"Shanti",

    "age":12,

    "email":"shanti@navgurukul.org",

    }
print(details["name"])

print(details["age"])

print(details["email"])
