s={1: ['Jean Castro'], 2: ['Lula Powell'], 3: ['Brian Howell'], 4: ['Lynne Foster'], 5: ['Zachary Simon']}
d={}
for i in s.items():
    d[i]={}
    d=d[i]
print(d)