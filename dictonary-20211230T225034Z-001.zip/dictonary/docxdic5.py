# (ascending and descending)
d={1:2,3:4,4:5,6:4}
for x in d:
    for y in d:
        d[x]>d[y]
        d[x],d[y]=d[y],d[x]
print(d)        