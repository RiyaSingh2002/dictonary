my_dict={45,56,78,89,23,567,89,34}
max=0
second_max=0
for i in my_dict:
    if max>my_dict[i]:
        max=my_dict[i]
        print(max)
    elif my_dict[i]<max and my_dict[i]>second_max:
        print(second_max)
    else:
        print('third_max') :