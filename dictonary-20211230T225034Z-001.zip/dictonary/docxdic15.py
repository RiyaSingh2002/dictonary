my_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
if my_dict['a']:
    del my_dict['a']
print(my_dict)