# def my_function():
#     name=input("enter your name:-")
#     roll_no=input("enter your roll number:-")
#     subject=input("enter your subject:-")
#     dic={}
      
    
#     print(dic)
# my_function()


