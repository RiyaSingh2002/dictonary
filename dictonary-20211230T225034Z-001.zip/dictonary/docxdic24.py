a=[{'item': 'item1', 'amount': 400}, {'item': 'item2', 'amount': 300}, 
{'item': 'item1', 'amount': 750}]
c={}
for d in a:
    d[["item"]]=d["amount"]
    d["item"]+=d["amount"]
print(c)    

