s={'S  001': ['Math', 'Science'], 'S    002': ['Math', 'English']}
d={}

