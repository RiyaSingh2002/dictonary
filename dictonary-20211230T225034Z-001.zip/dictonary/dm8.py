dict1=(input("enter your name"))
dict2=(input("enter your marks"))
x={}
for key in dict1:
    for value in dict2:
        x[key]=value
        x[dict1]=dict2
        break
print (str(x))