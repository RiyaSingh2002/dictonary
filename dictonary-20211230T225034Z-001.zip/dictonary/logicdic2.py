user_input=input("enter any word")
i=0
dic={}
while i<user_input:
            dic[user_input[i]]=i
i=i+1
print(dic)           
