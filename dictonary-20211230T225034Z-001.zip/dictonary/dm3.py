my_dict = {
        'data1':100,
        'data2': -54,
        'data3': 247
       }
sum=0       
for x in my_dict:
    sum=sum+my_dict[x]

print(sum)
