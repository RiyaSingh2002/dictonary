num_list = [1, 2, 3, 4]
my_dict=d={}
for i in num_list:
    d[i]={}
    d=d[i]
print(my_dict)
