dict={"name":"raju", "marks":56}
x=input("enter any thing:")
if x  in dict:
    print("exist")
else:
    print("not exist")    
