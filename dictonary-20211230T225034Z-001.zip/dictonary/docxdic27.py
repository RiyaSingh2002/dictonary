student = [{'id': 1, 'success': True, 'name': 'Lary'},
 {'id': 2, 'success': False, 'name': 'Rabi'},
 {'id': 3, 'success': True, 'name': 'Alex'}]

i = 0
for dict in student:
    if 'id' in dict:
        if dict['id'] == True:
            i+= 1
print(i)

