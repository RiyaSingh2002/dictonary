my_dict = {'a': [2, 3, 5],
           'b': [1, 8, 4],
           'c': [9, 0, 1]}

for i in my_dict.values():
    i.sort()
print(my_dict)