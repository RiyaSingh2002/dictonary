Sample_Dictionary={2:4,1:5}
Sample_Dictionary[6]=3
print(Sample_Dictionary)